package admin;

import code.databaseconnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class adminlogin extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        PrintWriter output = response.getWriter();

        try {

            Connection con = databaseconnection.establish();

            PreparedStatement ps = con.prepareStatement("select username from admin where email=? and password=?");
            ps.setString(1, email);
            ps.setString(2, password);
            
    
            if ( ps.executeQuery() != null ) {
                HttpSession session = (HttpSession) request.getSession();
                session.setAttribute("Admin", "admin");
                con.close();
                response.sendRedirect("../librarymanagement");
            }
        } catch (SQLException ex) {
            output.println(ex);
        } catch (ClassNotFoundException ex) {
            output.println(ex);
        } catch (InstantiationException ex) {
            output.println(ex);
        } catch (IllegalAccessException ex) {
            output.println(ex);
        }
    }

}
